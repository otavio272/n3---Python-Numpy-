import numpy as np
arr = np.array([-9, 1, 7], dtype=np.float32)
print(repr(arr))