import numpy as np
arr = np.array([[10, 11, 12], [21, 22, 23]],
dtype=np.float32)
print(repr(arr))