import numpy as np

arr = np.array([[2,4], [6,9]])

print(repr(arr[0]))
print(repr(arr[1]))

print(repr(arr[0][0]))
print(repr(arr[1][0]))